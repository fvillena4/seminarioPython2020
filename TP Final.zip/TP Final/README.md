Villena, Facundo. 16527/3
Tau, Felipe. 17156/9
#####################################


Pasos para jugar:
1. Cumplir los consideraciones para jugar
2. Ejecutar menu.py
3. A Disfrutar perdiendo contra la IA


#####################################

Reglas de ScrableAR
#####################################
El juego contará con una cierta cantidad de fichas de cada letra en su bolsa de fichas (letras) para repartir entre los jugadores.
Cuando comienza, se “reparten” siete (7) fichas a cada participante de forma aleatoria. El jugador tendrá asignado un “atril o estante” para almacenar sus fichas.
El jugador debe formar una palabra usando dos (2) o más letras, colocándolas horizontalmente (las letras ubicadas de izquierda a derecha) o verticalmente (en orden descendente) sobre el tablero. En la primera jugada, una de las letras deberá estar situada en el cuadro de “inicio del juego”.
Las palabras introducidas deben quedar pegadas con alguna de las ya existentes.
Las únicas palabras admitidas en el tablero serán adjetivos, sustantivos y/o verbos, de acuerdo a las opciones de configuración establecidas previamente.
Una vez que el jugador haya ingresado y confirmado correctamente la palabra, se le repondrá la cantidad de fichas que utilizó de su atril.
En cualquier momento del juego, el jugador puede decidir usar un turno para cambiar algunas o todas sus fichas, devolviéndolas a la bolsa de fichas del juego y reemplazándolas por la misma cantidad; al final, siempre debe tener siete (7). En este mismo turno, el jugador no podrá colocar ninguna palabra sobre el tablero. Esta opción no está disponible para la computadora, y el jugador sólo podrá usarla como máximo tres veces durante el juego.
En todo momento deberán estar visibles los puntajes de cada jugador. El mismo se calculará de la siguiente forma: se sumará el puntaje de cada letra y si la palabra cae en algún casillero con premio o descuento se sumará o restará el puntaje adicional. Se podrá mostrar la lista de palabras ingresadas al tablero con el puntaje individual obtenido en la jugada.
El juego termina cuando:
El jugador en turno no puede completar sus siete (7) fichas luego de una jugada, dado que no hay más fichas en la bolsa de fichas del juego.
Se acabó el tiempo de la partida.
Se presionó el botón “TERMINAR” partida.

#####################################

Consideraciones a la hora de jugar.
#####################################

Tener instalado:
Python 3.6.x
Pattern 2.6
PySimpleGui 3.25 o mayor

#####################################
